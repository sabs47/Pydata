Customer Survey:
=========================================================

Go to Setting / apps and search "Customer Survey" and Install

And, you are done with installation. Congratulations!
